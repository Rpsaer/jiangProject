package cn.zcbigdata.mybits_demo.entity;

public class newStudent {

    private int id;
    private int stu_id;
    private String stu_name;
    private String stu_grade;
    private String stu_sexy;
    private int stu_lesson;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getStu_id() {
        return stu_id;
    }
    public void setStu_id(int stu_id) {
        this.stu_id = stu_id;
    }
    public String getStu_name() {
        return stu_name;
    }
    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }
    public String getStu_grade() {
        return stu_grade;
    }
    public void setStu_grade(String stu_grade) {
        this.stu_grade = stu_grade;
    }
    public String getStu_sexy() {
        return stu_sexy;
    }
    public void setStu_sexy(String stu_sexy) {
        this.stu_sexy = stu_sexy;
    }
    public int getStu_lesson() {
        return stu_lesson;
    }
    public void setStu_lesson(int stu_lesson) {
        this.stu_lesson = stu_lesson;
    }
    @Override
    public String toString() {
        return "student [id=" + id + ", stu_id=" + stu_id + ", stu_name=" + stu_name + ", stu_grade=" + stu_grade
                + ", stu_sexy=" + stu_sexy + ", stu_lesson=" + stu_lesson + "]";
    }







}
