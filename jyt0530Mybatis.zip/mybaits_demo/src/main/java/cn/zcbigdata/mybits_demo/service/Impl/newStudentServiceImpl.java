package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.Student;
import cn.zcbigdata.mybits_demo.entity.newStudent;
import cn.zcbigdata.mybits_demo.entity.page;
import cn.zcbigdata.mybits_demo.mapper.StudentMapper;
import cn.zcbigdata.mybits_demo.mapper.newStudentMapper;
import cn.zcbigdata.mybits_demo.service.StudentService;
import cn.zcbigdata.mybits_demo.service.newStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Service
public class newStudentServiceImpl implements newStudentService {


    @Resource
    private newStudentMapper StudentDao;


    public List<newStudent> selectAll(page Page) {
        return this.StudentDao.selectAll(Page);
    }

    public List<newStudent> selectByStuId(int stu_id) {
        return this.StudentDao.selectByStuId(stu_id);
    }

    public List<newStudent> selectByStuName(String stu_name) {
        return this.StudentDao.selectByStuName(stu_name);
    }

    public List<newStudent> selectByStuSexy(String stu_sexy) {
        return this.StudentDao.selectByStuSexy(stu_sexy);
    }


    public 	int deleteByPrimaryKey(int stu_id) {
        return this.StudentDao.deleteByPrimaryKey(stu_id);
    }

    public int insert(newStudent Student) {
        return this.StudentDao.insert(Student);
    }

    public int updateByPrimaryKey(newStudent Student) {
        return this.StudentDao.updateByPrimaryKey(Student);
    }

}
