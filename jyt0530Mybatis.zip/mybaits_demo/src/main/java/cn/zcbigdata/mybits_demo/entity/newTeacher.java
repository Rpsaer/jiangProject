package cn.zcbigdata.mybits_demo.entity;

public class newTeacher {

    private int id;
    private int teacher_id;
    private String teacher_name;
    private int stu_lesson;
    private String stu_grade;
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getTeacher_id() {
        return teacher_id;
    }
    public void setTeacher_id(int teacher_id) {
        this.teacher_id = teacher_id;
    }
    public String getTeacher_name() {
        return teacher_name;
    }
    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }
    public int getStu_lesson() {
        return stu_lesson;
    }
    public void setStu_lesson(int stu_lesson) {
        this.stu_lesson = stu_lesson;
    }
    public String getStu_grade() {
        return stu_grade;
    }
    public void setStu_grade(String stu_grade) {
        this.stu_grade = stu_grade;
    }
    @Override
    public String toString() {
        return "teacher [id=" + id + ", teacher_id=" + teacher_id + ", teacher_name=" + teacher_name + ", stu_lesson="
                + stu_lesson + ", stu_grade=" + stu_grade + "]";
    }




}
