package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.newStudentService;
import cn.zcbigdata.mybits_demo.service.newTeacherService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 登录页面
 */
@Controller
@RequestMapping("/teacher")
public class newTeacherController {

    private static final Logger LOGGER = Logger.getLogger(newTeacherController.class);

    @Resource
    private newTeacherService TeacherService;

    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectAll(int page,int limit) throws Exception {
        page Page = new page();
        Page.setPage(page);
        Page.setLimit(limit);
        Page.setOffset((page-1)*limit);
        List<newTeacher> teacher=TeacherService.selectAll(Page);
        String[] colums= {"id","teacher_id","teacher_name","stu_lesson","stu_grade"};
        String data = ObjtoLayJson.ListtoJson(teacher, colums);
        System.out.println(data);
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/selectById", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectById(String teacher_id,int page,int limit) throws Exception {
        onePage Page = new onePage();
        Page.setPage(page);
        Page.setLimit(limit);
        Page.setOffset((page-1)*limit);
        newTeacher TEACHER = new newTeacher();
        try{
            TEACHER.setTeacher_id(dataCheck.check4(teacher_id));
        }catch(Exception e){
            System.out.println(teacher_id);
        }
       Integer teacher_idInteger = Integer.valueOf(teacher_id);
        Page.setTeacher_id(teacher_idInteger);
        List<Union> teacher=TeacherService.selectById(Page);
        String[] colums= {"teacher_name","teacher_id","stu_id","stu_name","stu_grade","stu_sexy","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(teacher, colums);
        System.out.println(data);
        return data;
    }


    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String insert(String teacher_id,String teacher_name,String stu_lesson,String stu_grade) throws Exception {
        newTeacher TEACHER = new newTeacher();
        String jsonString = "";
        try {
            TEACHER.setTeacher_id(dataCheck.check4(teacher_id));
            TEACHER.setStu_lesson(dataCheck.check4(stu_lesson));
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        TEACHER.setTeacher_name(teacher_name);
        TEACHER.setStu_grade(stu_grade);
        TeacherService.insert(TEACHER);
        jsonString="{\"data\":\"老师信息添加成功\"}";
        return jsonString;
    }

    @ResponseBody
    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String updateByPrimaryKey(String id,String teacher_id,String teacher_name,String stu_lesson,String stu_grade) throws Exception {
        newTeacher TEACHER = new newTeacher();
        String jsonString = "";
        try {
            TEACHER.setId(dataCheck.check4(id));
            TEACHER.setTeacher_id(dataCheck.check4(teacher_id));
            TEACHER.setStu_lesson(dataCheck.check4(stu_lesson));
            jsonString="{\"data\":\"老师信息修改完成\"}";
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        TEACHER.setTeacher_name(teacher_name);
        TEACHER.setStu_grade(stu_grade);
        TeacherService.updateByPrimaryKey(TEACHER);
        return jsonString;
    }
    @ResponseBody
    @RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String deleteByPrimaryKey(String teacher_id)throws Exception{
        newTeacher TEACHER = new newTeacher();
        try{
            TEACHER.setTeacher_id(dataCheck.check4(teacher_id));
        }catch(Exception e){
            LOGGER.info(e.getMessage());
        }
        Integer teacher_idInteger = Integer.valueOf(teacher_id);
        TeacherService.deleteByPrimaryKey(teacher_idInteger);
        String data = "{\"data\":\"删除成功\"}";
    return data ;
    }

}
