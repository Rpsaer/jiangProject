package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface newTeacherService {
    public List<newTeacher>  selectAll(page Page);

    public int insert(newTeacher Teacher);

    public int updateByPrimaryKey(newTeacher Teacher);

    public int deleteByPrimaryKey(int teacher_id);

    public List<Union> selectById(onePage Page);
}
