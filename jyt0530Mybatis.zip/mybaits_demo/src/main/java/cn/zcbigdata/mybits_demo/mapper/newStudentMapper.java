package cn.zcbigdata.mybits_demo.mapper;


import cn.zcbigdata.mybits_demo.entity.Filepath;
import cn.zcbigdata.mybits_demo.entity.newStudent;
import cn.zcbigdata.mybits_demo.entity.page;

import java.util.List;

public interface newStudentMapper {
    List<newStudent> selectAll(page Page);

    List<newStudent> selectByStuId(int stu_id);

    List<newStudent> selectByStuName(String stu_name);

    List<newStudent> selectByStuSexy(String stu_sexy);

    int deleteByPrimaryKey(int stu_id);

    int insert(newStudent Student);

    int updateByPrimaryKey(newStudent Student);
}