package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.Union;
import cn.zcbigdata.mybits_demo.entity.newGrade;
import cn.zcbigdata.mybits_demo.entity.newTeacher;
import cn.zcbigdata.mybits_demo.entity.page;

import java.util.List;

public interface newGradeService {
    public List<newGrade>  selectAll(page Page);

    public List<newGrade> selectGrade(String stu_grade);

    public  int deleteByGrade(int stu_grade);

    public int insert(newGrade Grade);

    public  int updataGrade(newGrade Grade);
}
