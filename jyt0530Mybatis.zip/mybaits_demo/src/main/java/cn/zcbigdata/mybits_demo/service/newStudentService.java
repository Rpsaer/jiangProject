package cn.zcbigdata.mybits_demo.service;

import cn.zcbigdata.mybits_demo.entity.newStudent;
import cn.zcbigdata.mybits_demo.entity.page;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface newStudentService {
    public List<newStudent> selectAll(page Page);

    public List<newStudent> selectByStuId(int stu_id);

    public List<newStudent> selectByStuName(String stu_name);

    public List<newStudent> selectByStuSexy(String stu_sexy);

    public int deleteByPrimaryKey(int stu_id);

    public int insert(newStudent Student);

    public int updateByPrimaryKey(newStudent Student);
}
