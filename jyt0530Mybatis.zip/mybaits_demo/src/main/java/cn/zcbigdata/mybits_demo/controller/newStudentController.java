package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.newStudent;
import cn.zcbigdata.mybits_demo.entity.page;
import cn.zcbigdata.mybits_demo.service.StudentService;
import cn.zcbigdata.mybits_demo.service.newStudentService;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import cn.zcbigdata.mybits_demo.entity.dataCheck;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 登录页面
 */
@Controller
@RequestMapping("/student")
public class newStudentController {

    private static final Logger LOGGER = Logger.getLogger(newStudentController.class);

    @Resource
    private newStudentService StudentService;


    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectAll(int page,int limit) throws Exception{
        page Page = new page();
        Page.setPage(page);
        Page.setLimit(limit);
        Page.setOffset((page-1)*limit);
        List<newStudent> logins = StudentService.selectAll(Page);
        String[] colums = {"id","stu_id","stu_name","stu_grade","stu_sexy","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(logins, colums);
        System.out.println(data);
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/selectByStuId", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectByStuId(String stu_id) throws Exception {
        newStudent STUDENT = new newStudent();
        String jsonString = "";
        try {
            STUDENT.setStu_id(dataCheck.check1(stu_id));
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        Integer stu_idInteger = Integer.valueOf(stu_id);
        List<newStudent> stu =StudentService.selectByStuId(stu_idInteger);
        String[] colums = {"id","stu_id","stu_name","stu_grade","stu_sexy","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(stu,colums);
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/selectByStuName", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectByStuName(String stu_name) throws Exception{
        newStudent STUDENT = new newStudent();
        STUDENT.setStu_name(stu_name);
        List<newStudent> stu =StudentService.selectByStuName(stu_name);
        String[] colums = {"id","stu_id","stu_name","stu_grade","stu_sexy","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(stu, colums);
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/selectByStuSexy", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectByStuSexy(String stu_sexy) throws Exception{
        newStudent STUDENT = new newStudent();
        STUDENT.setStu_sexy(stu_sexy);
        List<newStudent> stu =StudentService.selectByStuSexy(stu_sexy);
        String[] colums = {"id","stu_id","stu_name","stu_grade","stu_sexy","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(stu, colums);
        return data;
    }

    @ResponseBody
    @RequestMapping(value="/deleteByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String deleteByPrimaryKey(String stu_id) throws Exception {
        newStudent STUDENT = new newStudent();
        String jsonString = "";
        try {
            STUDENT.setStu_id(dataCheck.check2(stu_id));
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        Integer stu_idInteger = Integer.valueOf(stu_id);
        StudentService.deleteByPrimaryKey(stu_idInteger);
        jsonString="{\"data\":\"学生信息删除成功\"}";
        return jsonString;
    }

    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String insert(String stu_id,String stu_name,String stu_grade,String stu_sexy,String stu_lesson) throws Exception {
        newStudent STUDENT = new newStudent();
        String jsonString = "";
        try {
            STUDENT.setStu_id(dataCheck.check1(stu_id));
            STUDENT.setStu_lesson(dataCheck.check3(stu_lesson));
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        STUDENT.setStu_name(stu_name);
        STUDENT.setStu_grade(stu_grade);
        STUDENT.setStu_sexy(stu_sexy);
        StudentService.insert(STUDENT);
        jsonString="{\"data\":\"学生信息添加成功\"}";
        return jsonString;
    }


    @ResponseBody
    @RequestMapping(value="/updateByPrimaryKey", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String updateByPrimaryKey(String id,String stu_id,String stu_name,String stu_grade,String stu_sexy,String stu_lesson) throws Exception {
        newStudent STUDENT = new newStudent();
        String jsonString = "";
        try {
            STUDENT.setId(dataCheck.check4(id));
            STUDENT.setStu_id(dataCheck.check1(stu_id));
            STUDENT.setStu_lesson(dataCheck.check3(stu_lesson));
            jsonString="{\"data\":\"学生修改完成\"}";
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        STUDENT.setStu_name(stu_name);
        STUDENT.setStu_grade(stu_grade);
        STUDENT.setStu_sexy(stu_sexy);
        StudentService.updateByPrimaryKey(STUDENT);
        return jsonString;
    }

}
