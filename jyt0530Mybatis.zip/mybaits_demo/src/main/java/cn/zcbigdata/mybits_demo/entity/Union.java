package cn.zcbigdata.mybits_demo.entity;

public class Union {


    private String teacher_name;
    private int teacher_id;
    private int stu_id;
    private String stu_name;
    private String stu_grade;
    private String stu_sexy;
    private int stu_lesson;

    public String getTeacher_name() {
        return teacher_name;
    }

    public void setTeacher_name(String teacher_name) {
        this.teacher_name = teacher_name;
    }


    public int getStu_id() {
        return stu_id;
    }

    public void setStu_id(int stu_id) {
        this.stu_id = stu_id;
    }

    public String getStu_name() {
        return stu_name;
    }

    public void setStu_name(String stu_name) {
        this.stu_name = stu_name;
    }

    public String getStu_grade() {
        return stu_grade;
    }

    public void setStu_grade(String stu_grade) {
        this.stu_grade = stu_grade;
    }

    public String getStu_sexy() {
        return stu_sexy;
    }

    public void setStu_sexy(String stu_sexy) {
        this.stu_sexy = stu_sexy;
    }

    public int getStu_lesson() {
        return stu_lesson;
    }

    public void setStu_lesson(int stu_lesson) {
        this.stu_lesson = stu_lesson;
    }

    public int getTeacher_id() {
        return teacher_id;
    }

    public void setTeacher_id(int teacher_id) {
        this.teacher_id = teacher_id;
    }

    @Override
    public String toString() {
        return "Union{" +
                "teacher_name='" + teacher_name + '\'' +
                ", teacher_id=" + teacher_id +
                ", stu_id=" + stu_id +
                ", stu_name='" + stu_name + '\'' +
                ", stu_grade='" + stu_grade + '\'' +
                ", stu_sexy='" + stu_sexy + '\'' +
                ", stu_lesson=" + stu_lesson +
                '}';
    }
}
