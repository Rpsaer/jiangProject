package cn.zcbigdata.mybits_demo.mapper;



import cn.zcbigdata.mybits_demo.entity.newGrade;
import cn.zcbigdata.mybits_demo.entity.page;


import java.util.List;

public interface newGradeMapper {

    List<newGrade> selectAll(page Page);

    List<newGrade> selectGrade(String stu_grade);

    int deleteByGrade(int stu_grade);

    int insert(newGrade Grade);

    int updataGrade(newGrade Grade);
}