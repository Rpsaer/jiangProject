package cn.zcbigdata.mybits_demo.entity;

public class dataCheck {


    public static int check1(String x) throws Exception{
        try {
            return Integer.parseInt(x);
        }catch(Exception e) {
            throw new Exception("学号参数出错");
        }
    }

    public static int check2(String x) throws Exception{
        try {
            return Integer.parseInt(x);
        }catch(Exception e) {
            throw new Exception("删除失败，输入参数有问题");
        }
    }

    public static int check3(String x) throws Exception{
        try {
            return Integer.parseInt(x);
        }catch(Exception e) {
            throw new Exception("课程参数有问题");
        }
    }

    public static int check4(String x) throws Exception{
        try {
            return Integer.parseInt(x);
        }catch(Exception e) {
            throw new Exception("参数有问题");
        }
    }


}
