package cn.zcbigdata.mybits_demo.controller;

import cn.zcbigdata.mybits_demo.Util.ObjtoLayJson;
import cn.zcbigdata.mybits_demo.entity.*;
import cn.zcbigdata.mybits_demo.service.newGradeService;
import cn.zcbigdata.mybits_demo.service.newStudentService;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 登录页面
 */
@Controller
@RequestMapping("/grade")
public class newGradeController {

    private static final Logger LOGGER = Logger.getLogger(newGradeController.class);

    @Resource
    private newGradeService GradeService;


    @ResponseBody
    @RequestMapping(value="/selectAll", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectAll(int page,int limit ) throws Exception{
        page Page = new page();
        Page.setPage(page);
        Page.setLimit(limit);
        Page.setOffset((page-1)*limit);
        List<newGrade> grade = GradeService.selectAll(Page);
        String[] colums = {"id","stu_grade","teacher_id","teacher_name","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(grade, colums);
        System.out.println(data);
        return data;
    }


    @ResponseBody
    @RequestMapping(value="/selectGrade", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String selectGrade(String stu_grade) throws Exception{
        List<newGrade> grade = GradeService.selectGrade(stu_grade);
        String[] colums = {"id","stu_grade","teacher_id","teacher_name","stu_lesson"};
        String data = ObjtoLayJson.ListtoJson(grade, colums);
        System.out.println(data);
        return data;
    }


    @ResponseBody
    @RequestMapping(value="/deleteByGrade", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String deleteByGrade(String stu_grade) throws Exception{
       Integer stu_gradeInteger = Integer.valueOf(stu_grade);
            GradeService.deleteByGrade(stu_gradeInteger);
      String data = "{\"data\":\"删除成功\"}";
        return data;
    }


    @ResponseBody
    @RequestMapping(value="/insert", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String insert(String teacher_id,String teacher_name,String stu_lesson,String stu_grade) throws Exception {
        newGrade Grade = new newGrade();
        String jsonString = "";
        try {
            Grade.setTeacher_id(dataCheck.check4(teacher_id));
            Grade.setStu_lesson(dataCheck.check4(stu_lesson));
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        Grade.setTeacher_name(teacher_name);
        Grade.setStu_grade(stu_grade);
        GradeService.insert(Grade);
        jsonString="{\"data\":\"年级的信息添加成功\"}";
        return jsonString;
    }


    @ResponseBody
    @RequestMapping(value="/updataGrade", method=RequestMethod.GET,produces = "text/plain;charset=utf-8")
    public String updataGrade(String id,String teacher_id,String teacher_name,String stu_lesson,String stu_grade) throws Exception {
        newGrade Grade = new newGrade();
        String jsonString = "";
        try {
            Grade.setId(dataCheck.check4(id));
            Grade.setTeacher_id(dataCheck.check4(teacher_id));
            Grade.setStu_lesson(dataCheck.check4(stu_lesson));
            jsonString="{\"data\":\"年级信息修改完成\"}";
        }catch(Exception e){
            jsonString+="{\"data\":"+e.getMessage()+"}";
        }
        Grade.setTeacher_name(teacher_name);
        Grade.setStu_grade(stu_grade);
        GradeService.updataGrade(Grade);
        return jsonString;
    }



}
