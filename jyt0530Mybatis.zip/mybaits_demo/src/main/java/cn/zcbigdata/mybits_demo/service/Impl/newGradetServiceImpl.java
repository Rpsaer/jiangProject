package cn.zcbigdata.mybits_demo.service.Impl;

import cn.zcbigdata.mybits_demo.entity.newGrade;
import cn.zcbigdata.mybits_demo.entity.newStudent;
import cn.zcbigdata.mybits_demo.entity.page;
import cn.zcbigdata.mybits_demo.mapper.newGradeMapper;
import cn.zcbigdata.mybits_demo.mapper.newStudentMapper;
import cn.zcbigdata.mybits_demo.service.newGradeService;
import cn.zcbigdata.mybits_demo.service.newStudentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class newGradetServiceImpl implements newGradeService {


    @Resource
    private newGradeMapper GradeDao;


    public List<newGrade> selectAll(page Page) {
        return this.GradeDao.selectAll(Page);
    }

    public List<newGrade> selectGrade(String stu_grade){
        return this.GradeDao.selectGrade(stu_grade);
    }

    public  int deleteByGrade(int stu_grade){
        return this.GradeDao.deleteByGrade(stu_grade);
    }

    public int insert(newGrade Grade){
        return this.GradeDao.insert(Grade);
    }

    public  int updataGrade(newGrade Grade){
        return this.GradeDao.updataGrade(Grade);
    }
}
