package cn.zcbigdata.mybits_demo.mapper;


import cn.zcbigdata.mybits_demo.entity.*;

import java.util.List;

public interface newTeacherMapper {
    List<newTeacher>  selectAll(page Page);

    List<Union> selectById(onePage Page);

    int insert(newTeacher Teacher);

    int updateByPrimaryKey(newTeacher Teacher);

    int deleteByPrimaryKey(int teacher_id);
}