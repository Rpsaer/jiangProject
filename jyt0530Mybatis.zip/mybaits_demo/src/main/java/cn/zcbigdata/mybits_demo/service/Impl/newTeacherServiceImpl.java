package cn.zcbigdata.mybits_demo.service.Impl;
import cn.zcbigdata.mybits_demo.entity.Union;
import cn.zcbigdata.mybits_demo.entity.newTeacher;
import cn.zcbigdata.mybits_demo.entity.onePage;
import cn.zcbigdata.mybits_demo.entity.page;
import cn.zcbigdata.mybits_demo.mapper.newTeacherMapper;
import cn.zcbigdata.mybits_demo.service.newTeacherService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

@Service
public class newTeacherServiceImpl implements newTeacherService {


    @Resource
    private newTeacherMapper TeacherDao;

    public List<newTeacher> selectAll(page Page){
        return this.TeacherDao.selectAll(Page);
    }

    public int insert(newTeacher Teacher) {
        return  this.TeacherDao.insert(Teacher);
    }

    public int updateByPrimaryKey(newTeacher Teacher) {
        return this.TeacherDao.updateByPrimaryKey(Teacher);
    }

    public int deleteByPrimaryKey(int teacher_id) {
        return this.TeacherDao.deleteByPrimaryKey(teacher_id);
    }

    public   List<Union> selectById(onePage Page){
        return this.TeacherDao.selectById(Page);
    }
}
