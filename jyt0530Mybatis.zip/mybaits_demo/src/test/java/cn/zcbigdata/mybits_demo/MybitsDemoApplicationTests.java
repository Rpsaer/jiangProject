package cn.zcbigdata.mybits_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybitsDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
